/*
 * @Author: your name
 * @Date: 2020-08-20 08:21:56
 * @LastEditTime: 2020-08-20 08:56:28
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \vue-app-vant\src\main.js
 */
// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import App from './App'
import store from './store'
import router from './router'
import Vant from 'vant';
import 'amfe-flexible';
import 'vant/lib/index.css';
// import '@/utils/permission' // 检测token

Vue.use(Vant);
Vue.config.productionTip = false

/* eslint-disable no-new */
new Vue({
  el: '#app',
  store,
  router,
  components: { App },
  template: '<App/>'
})
